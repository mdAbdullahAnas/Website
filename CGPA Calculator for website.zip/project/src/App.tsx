import React, { useState } from 'react';
import { GraduationCap } from 'lucide-react';
import { Course, PreviousRecord } from './types';
import { University } from './data/universities';
import UniversitySelector from './components/UniversitySelector';
import PreviousRecordInput from './components/PreviousRecordInput';
import CurrentSemester from './components/CurrentSemester';
import CGPASummary from './components/CGPASummary';

function App() {
  const [selectedUniversity, setSelectedUniversity] = useState<University | null>(null);
  const [previousRecord, setPreviousRecord] = useState<PreviousRecord>({
    totalCredits: 0,
    cgpa: 0,
  });
  const [courses, setCourses] = useState<Course[]>([
    { name: '', credits: 3, grade: 4.0 }
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <GraduationCap size={48} className="text-blue-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800 mb-2">
              CGPA Calculator
            </h1>
            <p className="text-gray-600">
              Calculate your Cumulative Grade Point Average (CGPA) easily
            </p>
          </div>

          <UniversitySelector
            selectedUniversity={selectedUniversity}
            onUniversitySelect={setSelectedUniversity}
          />

          <PreviousRecordInput
            previousRecord={previousRecord}
            setPreviousRecord={setPreviousRecord}
          />

          <CurrentSemester
            courses={courses}
            setCourses={setCourses}
            selectedUniversity={selectedUniversity}
          />

          <CGPASummary
            courses={courses}
            previousRecord={previousRecord}
          />
        </div>
      </div>
    </div>
  );
}

export default App;