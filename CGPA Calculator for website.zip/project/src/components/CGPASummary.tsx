import React from 'react';
import { Course, PreviousRecord } from '../types';
import { calculateCGPA } from '../utils/calculateCGPA';

interface CGPASummaryProps {
  courses: Course[];
  previousRecord: PreviousRecord;
}

const CGPASummary: React.FC<CGPASummaryProps> = ({ courses, previousRecord }) => {
  const currentSemesterCGPA = calculateCGPA(courses);
  const currentSemesterCredits = courses.reduce((sum, course) => sum + course.credits, 0);
  
  const totalCredits = previousRecord.totalCredits + currentSemesterCredits;
  const totalCGPA = previousRecord.totalCredits === 0 
    ? currentSemesterCGPA
    : Number(((previousRecord.cgpa * previousRecord.totalCredits + 
        currentSemesterCGPA * currentSemesterCredits) / totalCredits).toFixed(2));

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <h2 className="text-lg font-bold text-gray-800 mb-2">This Semester</h2>
        <div className="text-3xl font-bold text-blue-600">{currentSemesterCGPA}</div>
        <p className="mt-2 text-gray-600">
          Credits: {currentSemesterCredits}
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <h2 className="text-lg font-bold text-gray-800 mb-2">Previous Record</h2>
        <div className="text-3xl font-bold text-green-600">{previousRecord.cgpa}</div>
        <p className="mt-2 text-gray-600">
          Credits: {previousRecord.totalCredits}
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <h2 className="text-lg font-bold text-gray-800 mb-2">Cumulative</h2>
        <div className="text-3xl font-bold text-indigo-600">{totalCGPA}</div>
        <p className="mt-2 text-gray-600">
          Total Credits: {totalCredits}
        </p>
      </div>
    </div>
  );
};

export default CGPASummary;