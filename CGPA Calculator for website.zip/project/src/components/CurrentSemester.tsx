import React from 'react';
import { BookOpen } from 'lucide-react';
import { Course } from '../types';
import { University } from '../data/universities';
import GradeInput from './GradeInput';

interface CurrentSemesterProps {
  courses: Course[];
  setCourses: React.Dispatch<React.SetStateAction<Course[]>>;
  selectedUniversity: University | null;
}

const CurrentSemester: React.FC<CurrentSemesterProps> = ({ 
  courses, 
  setCourses,
  selectedUniversity 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <div className="flex items-center gap-2 mb-4">
        <BookOpen className="text-blue-600" size={24} />
        <h2 className="text-xl font-bold text-gray-800">Current Semester Courses</h2>
      </div>
      <GradeInput 
        courses={courses} 
        setCourses={setCourses}
        selectedUniversity={selectedUniversity}
      />
    </div>
  );
};

export default CurrentSemester;