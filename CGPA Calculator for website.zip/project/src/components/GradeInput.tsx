import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Course } from '../types';
import { University } from '../data/universities';

interface GradeInputProps {
  courses: Course[];
  setCourses: React.Dispatch<React.SetStateAction<Course[]>>;
  selectedUniversity: University | null;
}

const GradeInput: React.FC<GradeInputProps> = ({ 
  courses, 
  setCourses, 
  selectedUniversity 
}) => {
  const addCourse = () => {
    setCourses([...courses, { name: '', credits: 3, grade: 4.0 }]);
  };

  const removeCourse = (index: number) => {
    setCourses(courses.filter((_, i) => i !== index));
  };

  const updateCourse = (index: number, field: keyof Course, value: string | number) => {
    const newCourses = [...courses];
    if (field === 'grade') {
      const gradeValue = Number(value);
      const maxGrade = selectedUniversity?.gradingSystem[0]?.numericGrade || 4.0;
      if (gradeValue > maxGrade) return;
      newCourses[index] = { ...newCourses[index], [field]: gradeValue };
    } else {
      newCourses[index] = { ...newCourses[index], [field]: value };
    }
    setCourses(newCourses);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-12 gap-4 mb-2 font-medium text-gray-700">
        <div className="col-span-5">Course Name</div>
        <div className="col-span-3">Credits</div>
        <div className="col-span-3">Grade Point</div>
        <div className="col-span-1"></div>
      </div>
      
      {courses.map((course, index) => (
        <div key={index} className="grid grid-cols-12 gap-4 items-center">
          <div className="col-span-5">
            <input
              type="text"
              placeholder="Course Name"
              value={course.name}
              onChange={(e) => updateCourse(index, 'name', e.target.value)}
              className="w-full p-2 border rounded-md"
            />
          </div>
          <div className="col-span-3">
            <input
              type="number"
              min="1"
              max="6"
              value={course.credits}
              onChange={(e) => updateCourse(index, 'credits', Number(e.target.value))}
              className="w-full p-2 border rounded-md"
            />
          </div>
          <div className="col-span-3">
            {selectedUniversity ? (
              <select
                value={course.grade}
                onChange={(e) => updateCourse(index, 'grade', Number(e.target.value))}
                className="w-full p-2 border rounded-md"
              >
                {selectedUniversity.gradingSystem.map((grade, i) => (
                  <option key={i} value={grade.numericGrade}>
                    {grade.letterGrade} ({grade.numericGrade.toFixed(2)})
                  </option>
                ))}
              </select>
            ) : (
              <input
                type="number"
                min="0"
                max="4"
                step="0.01"
                value={course.grade}
                onChange={(e) => updateCourse(index, 'grade', e.target.value)}
                className="w-full p-2 border rounded-md"
                placeholder="0.00 - 4.00"
              />
            )}
          </div>
          <div className="col-span-1 flex justify-center">
            <button
              onClick={() => removeCourse(index)}
              className="p-2 text-red-600 hover:bg-red-50 rounded-md"
            >
              <Trash2 size={20} />
            </button>
          </div>
        </div>
      ))}
      
      <div className="mt-4">
        <button
          onClick={addCourse}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          <Plus size={20} />
          Add Course
        </button>
      </div>
    </div>
  );
};

export default GradeInput;