import React, { useState } from 'react';
import { History } from 'lucide-react';
import { PreviousRecord } from '../types';
import Toast from './Toast';

interface PreviousRecordInputProps {
  previousRecord: PreviousRecord;
  setPreviousRecord: React.Dispatch<React.SetStateAction<PreviousRecord>>;
}

const PreviousRecordInput: React.FC<PreviousRecordInputProps> = ({
  previousRecord,
  setPreviousRecord,
}) => {
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const handleCGPAChange = (value: string) => {
    const cgpa = Number(value);
    if (cgpa > 4) {
      setToastMessage('CGPA cannot be greater than 4.00');
      setShowToast(true);
      return;
    }
    setPreviousRecord(prev => ({
      ...prev,
      cgpa: value === '' ? 0 : cgpa
    }));
  };

  const handleCreditsChange = (value: string) => {
    setPreviousRecord(prev => ({
      ...prev,
      totalCredits: value === '' ? 0 : Number(value)
    }));
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <Toast
        message={toastMessage}
        isVisible={showToast}
        onClose={() => setShowToast(false)}
      />
      
      <div className="flex items-center gap-2 mb-4">
        <History className="text-blue-600" size={24} />
        <h2 className="text-xl font-bold text-gray-800">Previous Academic Record</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Previous Total Credits Completed
          </label>
          <input
            type="number"
            min="0"
            value={previousRecord.totalCredits || ''}
            onChange={(e) => handleCreditsChange(e.target.value)}
            className="w-full p-2 border rounded-md"
            placeholder="Enter total credits"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Previous CGPA
          </label>
          <input
            type="number"
            min="0"
            max="4"
            step="0.01"
            value={previousRecord.cgpa || ''}
            onChange={(e) => handleCGPAChange(e.target.value)}
            className="w-full p-2 border rounded-md"
            placeholder="Enter CGPA (max 4.00)"
          />
        </div>
      </div>
    </div>
  );
};

export default PreviousRecordInput;