import React from 'react';
import { AlertCircle } from 'lucide-react';

interface ToastProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, isVisible, onClose }) => {
  if (!isVisible) return null;

  React.useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);

    return () => clearTimeout(timer);
  }, [isVisible, onClose]);

  return (
    <div className="fixed top-4 right-4 flex items-center gap-2 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded shadow-lg">
      <AlertCircle size={20} />
      <span>{message}</span>
    </div>
  );
};

export default Toast;