import React from 'react';
import { School } from 'lucide-react';
import { universities, University, GradeScale } from '../data/universities';

interface UniversitySelectorProps {
  selectedUniversity: University | null;
  onUniversitySelect: (university: University) => void;
}

const UniversitySelector: React.FC<UniversitySelectorProps> = ({
  selectedUniversity,
  onUniversitySelect,
}) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <div className="flex items-center gap-2 mb-4">
        <School className="text-blue-600" size={24} />
        <h2 className="text-xl font-bold text-gray-800">Select Your University</h2>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <div>
          <select
            className="w-full p-2 border rounded-md"
            value={selectedUniversity?.id || ''}
            onChange={(e) => {
              const university = universities.find(u => u.id === e.target.value);
              if (university) onUniversitySelect(university);
            }}
          >
            <option value="">Select a university</option>
            <optgroup label="Public Universities">
              {universities
                .filter(u => u.type === 'Public')
                .map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))
              }
            </optgroup>
            <optgroup label="Private Universities">
              {universities
                .filter(u => u.type === 'Private')
                .map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))
              }
            </optgroup>
          </select>
        </div>

        {selectedUniversity && (
          <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2">Grading System</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="px-4 py-2 border">Letter Grade</th>
                    <th className="px-4 py-2 border">Grade Point</th>
                    <th className="px-4 py-2 border">Marks Range</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedUniversity.gradingSystem.map((grade, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-4 py-2 border text-center">{grade.letterGrade}</td>
                      <td className="px-4 py-2 border text-center">{grade.numericGrade.toFixed(2)}</td>
                      <td className="px-4 py-2 border text-center">{grade.marksRange}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UniversitySelector;