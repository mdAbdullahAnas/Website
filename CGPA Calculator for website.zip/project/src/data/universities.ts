export interface GradeScale {
  letterGrade: string;
  numericGrade: number;
  marksRange: string;
}

export interface University {
  id: string;
  name: string;
  type: 'Public' | 'Private';
  gradingSystem: GradeScale[];
}

export const universities: University[] = [
  {
    id: 'buet',
    name: 'Bangladesh University of Engineering and Technology (BUET)',
    type: 'Public',
    gradingSystem: [
      { letterGrade: 'A+', numericGrade: 4.00, marksRange: '80-100' },
      { letterGrade: 'A', numericGrade: 3.75, marksRange: '75-79' },
      { letterGrade: 'B+', numericGrade: 3.50, marksRange: '70-74' },
      { letterGrade: 'B', numericGrade: 3.25, marksRange: '65-69' },
      { letterGrade: 'C+', numericGrade: 3.00, marksRange: '60-64' },
      { letterGrade: 'C', numericGrade: 2.75, marksRange: '55-59' },
      { letterGrade: 'D+', numericGrade: 2.50, marksRange: '50-54' },
      { letterGrade: 'D', numericGrade: 2.25, marksRange: '45-49' },
      { letterGrade: 'F', numericGrade: 0.00, marksRange: '0-44' }
    ]
  },
  {
    id: 'du',
    name: 'University of Dhaka (DU)',
    type: 'Public',
    gradingSystem: [
      { letterGrade: 'A+', numericGrade: 4.00, marksRange: '80-100' },
      { letterGrade: 'A', numericGrade: 3.75, marksRange: '75-79' },
      { letterGrade: 'A-', numericGrade: 3.50, marksRange: '70-74' },
      { letterGrade: 'B+', numericGrade: 3.25, marksRange: '65-69' },
      { letterGrade: 'B', numericGrade: 3.00, marksRange: '60-64' },
      { letterGrade: 'B-', numericGrade: 2.75, marksRange: '55-59' },
      { letterGrade: 'C+', numericGrade: 2.50, marksRange: '50-54' },
      { letterGrade: 'C', numericGrade: 2.25, marksRange: '45-49' },
      { letterGrade: 'D', numericGrade: 2.00, marksRange: '40-44' },
      { letterGrade: 'F', numericGrade: 0.00, marksRange: '0-39' }
    ]
  },
  {
    id: 'nsu',
    name: 'North South University (NSU)',
    type: 'Private',
    gradingSystem: [
      { letterGrade: 'A', numericGrade: 4.00, marksRange: '93-100' },
      { letterGrade: 'A-', numericGrade: 3.70, marksRange: '90-92' },
      { letterGrade: 'B+', numericGrade: 3.30, marksRange: '87-89' },
      { letterGrade: 'B', numericGrade: 3.00, marksRange: '83-86' },
      { letterGrade: 'B-', numericGrade: 2.70, marksRange: '80-82' },
      { letterGrade: 'C+', numericGrade: 2.30, marksRange: '77-79' },
      { letterGrade: 'C', numericGrade: 2.00, marksRange: '73-76' },
      { letterGrade: 'C-', numericGrade: 1.70, marksRange: '70-72' },
      { letterGrade: 'D+', numericGrade: 1.30, marksRange: '67-69' },
      { letterGrade: 'D', numericGrade: 1.00, marksRange: '60-66' },
      { letterGrade: 'F', numericGrade: 0.00, marksRange: '0-59' }
    ]
  },
  {
    id: 'bracu',
    name: 'BRAC University',
    type: 'Private',
    gradingSystem: [
      { letterGrade: 'A', numericGrade: 4.00, marksRange: '90-100' },
      { letterGrade: 'A-', numericGrade: 3.70, marksRange: '85-89' },
      { letterGrade: 'B+', numericGrade: 3.30, marksRange: '80-84' },
      { letterGrade: 'B', numericGrade: 3.00, marksRange: '75-79' },
      { letterGrade: 'B-', numericGrade: 2.70, marksRange: '70-74' },
      { letterGrade: 'C+', numericGrade: 2.30, marksRange: '65-69' },
      { letterGrade: 'C', numericGrade: 2.00, marksRange: '60-64' },
      { letterGrade: 'D', numericGrade: 1.00, marksRange: '50-59' },
      { letterGrade: 'F', numericGrade: 0.00, marksRange: '0-49' }
    ]
  }
];