import { University } from '../data/universities';

export interface Course {
  name: string;
  credits: number;
  grade: number;
}

export interface PreviousRecord {
  totalCredits: number;
  cgpa: number;
}

export interface AppState {
  selectedUniversity: University | null;
  previousRecord: PreviousRecord;
  courses: Course[];
}