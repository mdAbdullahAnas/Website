import { Course } from '../types';

export const calculateCGPA = (courses: Course[]): number => {
  if (courses.length === 0) return 0;

  const totalCredits = courses.reduce((sum, course) => sum + course.credits, 0);
  const totalGradePoints = courses.reduce(
    (sum, course) => sum + course.credits * course.grade,
    0
  );

  return Number((totalGradePoints / totalCredits).toFixed(2));
};