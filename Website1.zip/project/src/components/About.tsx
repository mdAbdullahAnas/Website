import React from 'react';

export default function About() {
  return (
    <section id="about" className="py-20 px-4 bg-gray-800/50">
      <div className="max-w-4xl mx-auto text-white">
        <h2 className="text-4xl font-bold mb-12 text-center">About Me</h2>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-gray-300">
              Hello! I am a third-year student at the American International
              University-Bangladesh (AIUB). My passion lies in Android
              development, and I'm continually exploring ways to create impactful
              mobile applications.
            </p>
            <p className="text-gray-300">
              I've developed a CGPA Calculator app, now live on the Google Play
              Store, which has helped students easily manage and calculate their
              academic performance. Currently, I'm working on a simple game,
              which has allowed me to dive deeper into game design and improve
              my programming skills.
            </p>
            <div className="space-y-2">
              <h3 className="text-xl font-semibold">Personal Information</h3>
              <ul className="space-y-2 text-gray-300">
                <li><strong>Phone:</strong> 01984298833</li>
                <li><strong>Email:</strong> abdullahanas100200300@gmail.com</li>
                <li><strong>Location:</strong> Kuril, Dhaka, Bangladesh</li>
                <li><strong>Current Status:</strong> 7th semester student at AIUB</li>
              </ul>
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Skills</h3>
            <ul className="space-y-2 text-gray-300">
              <li>• Android Development (Kotlin)</li>
              <li>• Microsoft Office</li>
              <li>• Engineering</li>
              <li>• Mobile App Development</li>
              <li>• Problem Solving</li>
            </ul>
            <h3 className="text-xl font-semibold mt-8">Hobbies</h3>
            <ul className="space-y-2 text-gray-300">
              <li>• Gardening</li>
              <li>• Reading storybooks</li>
              <li>• Exploring new technologies</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}