import React from 'react';
import { Phone, Mail, MapPin, Linkedin, Github, Facebook } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 px-4 bg-gray-800/50">
      <div className="max-w-4xl mx-auto text-white">
        <h2 className="text-4xl font-bold mb-12 text-center">Contact Me</h2>
        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-500/20 p-3 rounded-full">
                <Phone className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold">Phone</h3>
                <p className="text-gray-300">01984298833</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="bg-blue-500/20 p-3 rounded-full">
                <Mail className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold">Email</h3>
                <p className="text-gray-300">abdullahanas100200300@gmail.com</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="bg-blue-500/20 p-3 rounded-full">
                <MapPin className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold">Location</h3>
                <p className="text-gray-300">Kuril, Dhaka, Bangladesh</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-8">
            <h3 className="text-xl font-semibold">Social Links</h3>
            <div className="space-y-4">
              <a 
                href="https://www.linkedin.com/in/md-abdullah-anas-5a4914253"
                className="flex items-center space-x-4 text-gray-300 hover:text-white transition-colors"
              >
                <Linkedin className="w-6 h-6" />
                <span>LinkedIn Profile</span>
              </a>
              
              <a 
                href="https://github.com/mdAbdullahAnas"
                className="flex items-center space-x-4 text-gray-300 hover:text-white transition-colors"
              >
                <Github className="w-6 h-6" />
                <span>GitHub Profile</span>
              </a>
              
              <a 
                href="https://www.facebook.com/md-abdullah-anas-5a4914253"
                className="flex items-center space-x-4 text-gray-300 hover:text-white transition-colors"
              >
                <Facebook className="w-6 h-6" />
                <span>Facebook Profile</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}