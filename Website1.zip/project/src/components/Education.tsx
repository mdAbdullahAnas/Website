import React from 'react';

export default function Education() {
  const education = [
    {
      school: "American International University-Bangladesh",
      degree: "BSc in Computer Science",
      period: "August 2022 - Present",
      details: "Currently in 7th semester, focusing on Computer Science and Android Development"
    },
    {
      school: "Rangpur Government College, Rangpur",
      degree: "HSC",
      period: "January 2020 - March 2022",
      details: "Completed Higher Secondary Certificate"
    },
    {
      school: "Cantonment Public School & College Saidpur",
      degree: "SSC",
      period: "January 2017 - February 2019",
      details: "Completed Secondary School Certificate"
    }
  ];

  return (
    <section id="education" className="py-20 px-4 bg-gray-900">
      <div className="max-w-4xl mx-auto text-white">
        <h2 className="text-4xl font-bold mb-12 text-center">Education</h2>
        <div className="space-y-8">
          {education.map((edu, index) => (
            <div 
              key={index}
              className="bg-gray-800/50 p-6 rounded-lg transform hover:scale-105 transition-transform"
            >
              <h3 className="text-xl font-semibold text-blue-400">{edu.school}</h3>
              <p className="text-gray-300 mt-2">{edu.degree}</p>
              <p className="text-gray-400 text-sm mt-1">{edu.period}</p>
              <p className="text-gray-300 mt-2">{edu.details}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}