import React from 'react';
import { Github, Linkedin, Mail, Facebook, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex flex-col items-center justify-center text-white relative pt-16">
      <div className="text-center space-y-6 animate-fade-in">
        <div className="relative w-48 h-48 mx-auto mb-8">
          <img
            src="https://avatars.githubusercontent.com/u/mdAbdullahAnas"
            alt="Abdullah Anas"
            className="rounded-full border-4 border-blue-500 shadow-xl animate-profile"
          />
        </div>
        <h1 className="text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500 animate-gradient">
          Abdullah Anas
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto animate-slide-up">
          Student at AIUB | Android Developer | BSc in Computer Science
        </p>
        <div className="flex gap-6 justify-center mt-8">
          <a href="https://github.com/mdAbdullahAnas" className="transform hover:scale-110 transition-transform">
            <Github className="w-8 h-8" />
          </a>
          <a href="https://www.linkedin.com/in/md-abdullah-anas-5a4914253" className="transform hover:scale-110 transition-transform">
            <Linkedin className="w-8 h-8" />
          </a>
          <a href="https://www.facebook.com/md-abdullah-anas-5a4914253" className="transform hover:scale-110 transition-transform">
            <Facebook className="w-8 h-8" />
          </a>
          <a href="mailto:abdullahanas100200300@gmail.com" className="transform hover:scale-110 transition-transform">
            <Mail className="w-8 h-8" />
          </a>
        </div>
      </div>
      <div className="absolute bottom-10 animate-bounce">
        <ChevronDown className="w-8 h-8" />
      </div>
    </section>
  );
}